﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MoralesLarios.CustomsControls.HelpControls.EventArgs;

namespace MoralesLarios.CustomsControls.HelpControls
{

    public delegate void ElementPopulateEventHandler(object sender, RoutedElementPopulateEventArgs e);


}
