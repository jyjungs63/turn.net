﻿using MoralesLarios.CustomsControls.HelpControls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MoralesLarios.CustomsControls.Factories
{
    public class ObjectsFactory
    {

        //public static SupportFilteresSearch CreateSupportFilteresSearch(IEnumerable<object> source)
        //{
        //    IPopulateStackPanelControls populateStackPanelContros = new PopulateStackPanelControls()

        //    SupportFilteresSearch result = new SupportFilteresSearch()
        //}



    }
}
