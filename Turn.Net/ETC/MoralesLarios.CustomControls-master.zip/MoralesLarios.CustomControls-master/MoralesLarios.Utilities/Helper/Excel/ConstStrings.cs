﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MoralesLarios.Utilities.Helper.Excel
{
    internal static class ConstStrings
    {
        public const string COPY_ALL_MENU_HEADER  = "Copy All           (Ctrl + A)";
        public const string COPY_MENU_HEADER      = "Copy Selected (Ctrl + C)";
        public const string PASTE_ALL_MENU_HEADER = "Paste                (Ctrl + V)";
    }
}
