﻿namespace MoralesLarios.Utilities.Excel
{
    internal class KeyBindingWorker : IKeyBindingWorker
    {





                //        if(itemsControl.InputBindings.Count > 0)
                //{
                //    var keyBindingsToRemove = itemsControl.InputBindings.ToListObj().OfType<KeyBinding>()
                //                              .Where(a => a.Key == Key.A || a.Key == Key.C).ToList();


    }

}