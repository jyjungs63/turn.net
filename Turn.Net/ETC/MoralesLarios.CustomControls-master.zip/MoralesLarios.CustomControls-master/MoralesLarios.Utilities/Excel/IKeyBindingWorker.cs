﻿namespace MoralesLarios.Utilities.Excel
{
    internal interface IKeyBindingWorker
    {
    }
}