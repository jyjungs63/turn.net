# CustomControls and Utilities
XAML Controls

CustomControls is a XAML library of WPF controls.

## SearchAll

Is a very easy filter control.

![alt tag](https://1.bp.blogspot.com/-09lxTGxnGWQ/WJoyrXLD1iI/AAAAAAAAI24/7a-iFNi501czAxGHOSVS_CFiaNnNMAwoQCK4B/s1600/SearchAllFlash1.gif)

Installation and documentation in http://puntonetalpunto.blogspot.com.es/2017/02/wpf-searchall-control-essentials.html


## ExcelActions

Easy Copy/Paste between WPF ItemsControl and Excel

![alt tag](https://2.bp.blogspot.com/-s9QSRASZ6fk/WK4WuNxV-RI/AAAAAAAAI_g/tvLSr0nKk0YBt5ln66QPACsGWDmD4QOsgCK4B/s1600/Initial_low4.gif)

Installation and documentation in http://puntonetalpunto.blogspot.com.es/2017/02/easy-wpf-excel-copypaste.html
